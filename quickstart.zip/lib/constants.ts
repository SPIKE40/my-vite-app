export const PATHS = {
    HOME: "/",
    PROFILE: "/profile",
  };
  
  // Common strings or names
  export const APP_NAME = "msal-nextjs-spa-example";
  export const COPYRIGHT = "© 2024 My Company";
  
  // Other global configurations
//   export const API_URL =
//     process.env.NEXT_PUBLIC_API_URL || "https://api.example.com";
  
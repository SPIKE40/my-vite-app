import React from "react";
import NavMenu from "./NavMenu";

export const SideBar = () => {
  return (
    <NavMenu/>
  );
};

export default SideBar;